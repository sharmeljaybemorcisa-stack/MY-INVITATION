# Invitation YES / NO Response System

This project gives you:
- A romantic invitation card.
- YES and NO buttons.
- A Google Sheet database of responses.
- An email notification whenever she answers.
- Date/time recording.

## Setup

### 1. Create the database
Create a new Google Sheet.

### 2. Add the backend
Open:
Extensions > Apps Script

Delete the existing code and paste everything from `Code.gs`.

Change:
YOUR_EMAIL_HERE@gmail.com

to the email address where you want notifications.

Save.

### 3. Deploy
Click:
Deploy > New deployment

Choose:
Web app

Set:
Execute as: Me
Who has access: Anyone

Click Deploy and authorize the script.

Copy the Web App URL.

### 4. Connect the invitation
Open `invitation.html`.

Find:

const API_URL = "PASTE_YOUR_GOOGLE_APPS_SCRIPT_URL_HERE";

Replace the text inside the quotes with your Web App URL.

### 5. Edit your invitation
Change:
YOUR DATE HERE
YOUR TIME HERE
YOUR PLACE HERE

### 6. Publish it
You can upload `invitation.html` to a static website host such as GitHub Pages, Netlify, or another HTML hosting service.

Then send her the resulting link.

## What happens

If she clicks YES:
- The answer is saved in Google Sheets.
- You receive an email saying she said YES.
- The page shows a confirmation.

If she clicks NO:
- The answer is saved in Google Sheets.
- You receive an email saying she said NO.
- The page shows a confirmation.

Important:
A browser cannot send a notification directly to you from an ordinary HTML file. The Google Apps Script backend handles the saving and email notification.
